# Telegram Bot Media Downloader & Transcriber

This bot can download videos or audio from various platforms like YouTube, TikTok, Instagram, and more,
then transcribes them using speech recognition.

## Features
- Download video/audio from social links
- Transcribe the audio content
- Send summary with a CTA button

## Deployment (Render)
1. Upload this repo to GitHub.
2. Go to [Render](https://render.com) > New > Background Worker.
3. Connect your GitHub repo and choose this project.
4. Set environment variables if needed.
5. Deploy.

## Requirements
Ensure `ffmpeg` is available in your environment (Render supports this by default).
