
import shutil
import telebot
import yt_dlp
import os
import uuid
import subprocess
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import threading
import time
import requests
import speech_recognition as sr
from PIL import Image
from io import BytesIO

# BOT TOKEN
bot = telebot.TeleBot("7757263177:AAH0HlqPxUmAjVx7ehGHnw_0fynfJ4VvVqQ")

# Directory to store downloads
DOWNLOAD_DIR = "downloads"
if os.path.exists(DOWNLOAD_DIR):
    shutil.rmtree(DOWNLOAD_DIR)
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

# CTA button link
BALOW_LINK = "https://www.tiktok.com/@zack3d2?_t=ZN-8vMGXY3EkEw&_r=1"

def get_balow_button():
    keyboard = InlineKeyboardMarkup()
    button = InlineKeyboardButton(text="Summarize | Get", url=BALOW_LINK)
    keyboard.add(button)
    return keyboard

def is_supported_url(url):
    platforms = ['tiktok.com', 'youtube.com', 'pinterest.com', 'pin.it', 'youtu.be',
                 'instagram.com', 'snapchat.com', 'facebook.com', 'x.com', 'twitter.com']
    return any(p in url.lower() for p in platforms)

def is_youtube_url(url):
    return 'youtube.com' in url.lower() or 'youtu.be' in url.lower()

@bot.message_handler(commands=['start'])
def start_handler(message):
    first_name = message.from_user.first_name or "there"
    username = f"@{message.from_user.username}" if message.from_user.username else first_name
    text = f"👋 Salam {username} sand me a video link or\nvideo, audio, voice massage"
    bot.send_message(message.chat.id, text, parse_mode="Markdown")

@bot.message_handler(content_types=['voice', 'video_note', 'audio', 'video'])
def handle_audio_message(message):
    file_path = None
    try:
        if message.voice:
            file_info = bot.get_file(message.voice.file_id)
        elif message.video_note:
            file_info = bot.get_file(message.video_note.file_id)
        elif message.video:
            file_info = bot.get_file(message.video.file_id)
        else:
            file_info = bot.get_file(message.audio.file_id)

        unique_id = str(uuid.uuid4())
        file_path = os.path.join(DOWNLOAD_DIR, f"{unique_id}.ogg")
        downloaded_file = bot.download_file(file_info.file_path)

        with open(file_path, 'wb') as new_file:
            new_file.write(downloaded_file)

        try:
            bot.send_chat_action(message.chat.id, 'typing')
            transcription = transcribe_audio(file_path)
            if transcription:
                bot.send_message(message.chat.id, transcription, reply_markup=get_balow_button())
            else:
                bot.send_message(message.chat.id, "Codka lagama turjumi karin.")
        finally:
            if os.path.exists(file_path):
                os.remove(file_path)

    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

@bot.message_handler(func=lambda msg: is_youtube_url(msg.text))
def handle_youtube_url(msg):
    url = msg.text
    try:
        bot.send_chat_action(msg.chat.id, 'typing')
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
            'extract_flat': True,
            'skip_download': True,
            'outtmpl': os.path.join(DOWNLOAD_DIR, '%(title)s.%(ext)s'),
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info_dict = ydl.extract_info(url, download=False)
            thumbnail_url = info_dict.get('thumbnail')
            title = info_dict.get('title', 'YouTube Video')
            formats = info_dict.get('formats', [])

        resolutions = {}
        for f in formats:
            if f.get('vcodec') != 'none' and f.get('acodec') != 'none' and f.get('height') is not None:
                height = f['height']
                if height <= 1080:
                    resolutions[f'{height}p'] = f['format_id']

        if not resolutions:
            bot.send_message(msg.chat.id, "Ma jiro tayo muuqaal ah oo la heli karo.")
            return

        markup = InlineKeyboardMarkup(row_width=3)
        buttons = []
        sorted_resolutions = sorted(resolutions.keys(), key=lambda x: int(x[:-1]))
        for res in sorted_resolutions:
            format_id = resolutions[res]
            video_id = str(uuid.uuid4())[:8]
            bot.video_info = getattr(bot, 'video_info', {})
            bot.video_info[video_id] = {'url': url, 'format_id': format_id}
            buttons.append(InlineKeyboardButton(res, callback_data=f'dl:{video_id}'))
        markup.add(*buttons)

        if thumbnail_url:
            try:
                response = requests.get(thumbnail_url)
                response.raise_for_status()
                image = Image.open(BytesIO(response.content))
                bio = BytesIO()
                image.save(bio, 'JPEG')
                bio.seek(0)
                bot.send_photo(msg.chat.id, photo=bio, caption=f"Dooro tayada aad rabto inaad soo dejiso: {title}", reply_markup=markup)
            except Exception:
                bot.send_message(msg.chat.id, f"Dooro tayada aad rabto inaad soo dejiso: {title}", reply_markup=markup)
        else:
            bot.send_message(msg.chat.id, f"Dooro tayada aad rabto inaad soo dejiso: {title}", reply_markup=markup)

    except Exception as e:
        bot.send_message(msg.chat.id, f"Error extracting YouTube info: {e}")

@bot.callback_query_handler(func=lambda call: call.data.startswith('dl:'))
def download_youtube_video(call):
    try:
        video_id = call.data.split(':')[1]
        if not hasattr(bot, 'video_info') or video_id not in bot.video_info:
            bot.answer_callback_query(call.id, "Download expired. Please try again.")
            return
        video_data = bot.video_info[video_id]
        url = video_data['url']
        format_id = video_data['format_id']
        bot.answer_callback_query(call.id, f"Soo dejinta tayada {format_id}...")
        bot.send_chat_action(call.message.chat.id, 'record_video')
        output_path = os.path.join(DOWNLOAD_DIR, f"{uuid.uuid4()}.mp4")
        ydl_opts = {
            'format': format_id,
            'outtmpl': output_path,
            'quiet': True,
            'no_warnings': True,
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])

        bot.send_chat_action(call.message.chat.id, 'upload_video')
        with open(output_path, 'rb') as video_file:
            bot.send_video(call.message.chat.id, video_file, reply_to_message_id=call.message.message_id)

        try:
            bot.send_chat_action(call.message.chat.id, 'typing')
            transcription = transcribe_audio(output_path)
            if transcription and transcription != "Could not understand the audio":
                bot.send_message(call.message.chat.id, transcription, reply_markup=get_balow_button())
        except Exception as e:
            bot.send_message(call.message.chat.id, f"Error transcribing video: {e}")

    except Exception as e:
        bot.send_message(call.message.chat.id, f"Error downloading video: {e}")
    finally:
        if os.path.exists(output_path):
            os.remove(output_path)

@bot.message_handler(func=lambda msg: is_supported_url(msg.text) and not is_youtube_url(msg.text))
def handle_social_video(msg):
    url = msg.text
    video_path = None
    try:
        bot.send_chat_action(msg.chat.id, 'record_video')
        video_path = download_video_any(url)
        transcription_result = []

        def run_transcription():
            bot.send_chat_action(msg.chat.id, 'typing')
            transcription_result.append(transcribe_audio(video_path))

        trans_thread = threading.Thread(target=run_transcription)
        trans_thread.start()

        bot.send_chat_action(msg.chat.id, 'upload_video')
        with open(video_path, 'rb') as video_file:
            bot.send_video(msg.chat.id, video_file)

        trans_thread.join()
        transcription = transcription_result[0] if transcription_result else None

        if transcription and transcription != "Could not understand the audio":
            bot.send_chat_action(msg.chat.id, 'typing')
            bot.send_message(msg.chat.id, transcription, reply_markup=get_balow_button())

    except Exception as e:
        bot.send_message(msg.chat.id, f"Error: {e}")
    finally:
        if video_path and os.path.exists(video_path):
            os.remove(video_path)

def download_video_any(url):
    unique_id = str(uuid.uuid4())
    output_path = os.path.join(DOWNLOAD_DIR, f"{unique_id}.mp4")
    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio/best[ext=mp4]/best',
        'merge_output_format': 'mp4',
        'outtmpl': output_path,
        'quiet': True,
        'noplaylist': True,
        'extract_flat': False,
        'extractor_args': {
            'pinterest': {
                'video_only': False,
            }
        }
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])
    return output_path

def transcribe_audio(file_path):
    r = sr.Recognizer()
    wav_path = None
    try:
        wav_path = os.path.join(DOWNLOAD_DIR, f"{uuid.uuid4()}.wav")
        subprocess.run([
            'ffmpeg', '-i', file_path,
            '-vn',
            '-acodec', 'pcm_s16le',
            '-ar', '16000',
            '-ac', '1',
            wav_path,
            '-y',
            '-loglevel', 'quiet'
        ], check=True)

        with sr.AudioFile(wav_path) as source:
            r.adjust_for_ambient_noise(source, duration=0.5)
            audio = r.record(source)

        text = r.recognize_google(audio, language="en-US")
        return text

    except sr.UnknownValueError:
        return "Could not understand the audio"
    except sr.RequestError as e:
        print(f"Could not request results from Google Speech Recognition service; {e}")
        return None
    except subprocess.CalledProcessError:
        print(f"Error extracting audio from {file_path}")
        return None
    except Exception as e:
        print(f"Transcription error: {e}")
        return None
    finally:
        if wav_path and os.path.exists(wav_path):
            os.remove(wav_path)

bot.delete_webhook()
bot.remove_webhook()

while True:
    try:
        bot.polling(none_stop=True, interval=2, timeout=20, long_polling_timeout=20)
    except requests.exceptions.ConnectionError as e:
        print("Connection error occurred. Retrying in 5 seconds...", e)
        time.sleep(5)
        continue
    except Exception as e:
        print("Unexpected error occurred:", e)
        time.sleep(5)
        continue
